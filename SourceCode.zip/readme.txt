1.Run `node-red-start` to start the nodeRED service.
2.Make sure you open the node red webpage using https instead of http.
3.The NodeRED local UI can be accessed through /ui endpoint.
4.Forward the part 3000 using VScode, this port is for the local grafana dashboard