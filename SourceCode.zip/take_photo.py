from picamera import PiCamera
from time import sleep


camera = PiCamera()
camera.resolution = (1024, 768)
camera.start_preview()
sleep(2)  # Allow the camera to adjust

camera.capture('/home/pi/Desktop/pi_cam/imgs/image.jpg')
print "Image captured successfully!"

# camera.start_recording('/home/pi/video.h264')
# sleep(10)  # Record for 10 seconds
# camera.stop_recording()
# print "Video recorded successfully!"

camera.stop_preview()
camera.close() 